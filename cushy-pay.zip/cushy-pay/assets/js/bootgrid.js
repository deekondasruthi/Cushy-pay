/* ============================================================
 * BootGrid Tables
 * Generate advanced tables with sorting, export options using
 * jQuery BootGrid plugin
 * For DEMO purposes only. Extract what you need.
 * ============================================================ */
(function($) {

    'use strict';

});